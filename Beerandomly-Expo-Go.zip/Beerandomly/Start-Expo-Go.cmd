@echo off
setlocal
cd /d "%~dp0"
where npm.cmd >nul 2>nul
if errorlevel 1 (
  echo Install Node.js LTS from https://nodejs.org/ and then reopen this file.
  pause
  exit /b 1
)
if not exist "node_modules\.bin\expo.cmd" (
  echo Setting up Beerandomly for the first run...
  call npm ci --no-audit --no-fund
  if errorlevel 1 goto failed
)
echo Connect this computer and your phone to the same Wi-Fi.
choice /c YN /m "Are you testing on an iPhone"
if errorlevel 2 goto start
call npx --no-install expo whoami
echo Expo Go on your iPhone needs the same Expo account as this computer.
choice /c YN /m "Sign in or switch Expo accounts on this computer"
if errorlevel 2 goto start
call npx --no-install expo login
if errorlevel 1 goto failed
:start
call npm start
if errorlevel 1 goto failed
exit /b 0
:failed
echo Launch stopped. Check the message above, then reopen this file to retry.
pause
exit /b 1
