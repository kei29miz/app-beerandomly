export const SITE = 'https://beerandomly.space';

export async function getPublic(path, params = {}, signal) {
  const query = Object.entries(params).filter(([,v]) => v !== '' && v != null)
    .map(([key,value]) => encodeURIComponent(key) + '=' + encodeURIComponent(value)).join('&');
  const controller = new AbortController();
  const stop = () => controller.abort();
  if (signal?.aborted) stop();
  signal?.addEventListener('abort', stop);
  const timer = setTimeout(stop, 15000);
  try {
    const response = await fetch(SITE + '/wp-json/bhm/v1/' + path + (query ? '?' + query : ''), {
      credentials: 'omit', headers: {Accept: 'application/json'}, signal: controller.signal,
    });
    if (!response.ok) throw new Error(response.status === 404 ? 'This item is no longer available.' : 'Beerandomly could not load this page.');
    return await response.json();
  } catch (e) {
    if (controller.signal.aborted || e instanceof TypeError) throw new Error('Check your connection and try again.');
    throw e;
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener('abort', stop);
  }
}
