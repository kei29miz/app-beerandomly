# Beerandomly for Expo Go

## Try it on your phone

1. Install Node.js 24 LTS (24.3 or later) on your computer and an Expo Go build compatible with SDK 58 on your phone. Use https://nodejs.org/ and https://expo.dev/go.
2. Extract the entire ZIP on your computer. On Windows, double-click **Start-Expo-Go.cmd** inside the Beerandomly folder. The first run downloads the packages. Select your phone type when asked.
3. Connect your phone and computer to the same Wi-Fi. Leave the terminal open while you test. Scan the terminal QR code with **Expo Go → Scan QR** on Android or the **Camera** app on iPhone. On iPhone, sign in to the same Expo account in Expo Go and on the computer.

### macOS, Linux, or manual Windows launch

From the extracted Beerandomly folder run:

```sh
npm ci
npm start
```

For iPhone, run `npx expo login` before starting the server. If your phone cannot connect, allow Node.js on your private network and make sure both devices are on the same non-guest Wi-Fi. If Expo Go reports an SDK mismatch, choose SDK 58 and your device at https://expo.dev/go. Expo provides device-specific installation instructions.

## Using the app

- **Hive** shows public posts in chronological order. Pull down to refresh. Tap a post to read it and share its link.
- **Explore** browses the site's topic directory and filters public posts by topic or search term. Tap Search or the keyboard's search key to submit.
- **People** finds community members by name, handle, headline, or skill. The detail screen shows the profile information the API exposes to visitors.
- **Account** opens your existing Google/WordPress member session in the phone's browser. Create posts, send messages, view credits, or edit your profile there. Close the browser sheet or use Back to return to the app.
- The app uses the public Beerandomly endpoints on beerandomly.space. Posting from the signed-in browser publishes to the live site. The app requires an internet connection.
