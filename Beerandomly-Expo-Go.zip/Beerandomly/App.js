import React, {useEffect, useRef, useState} from 'react';
import {ActivityIndicator, Alert, BackHandler, Image, Pressable, RefreshControl, ScrollView, Share, StatusBar, StyleSheet, Text, TextInput, View} from 'react-native';
import {SafeAreaProvider, SafeAreaView} from 'react-native-safe-area-context';
import Feather from '@expo/vector-icons/Feather';
import * as Browser from 'expo-web-browser';
import {SITE, getPublic} from './api';

const green = '#124735', ink = '#132F24', muted = '#526759', honey = '#FFCD54';
const tabs = [['Hive','home'],['Explore','compass'],['People','users'],['Account','user']];
const topicsIcons = {wordpress:'layout','web-development':'globe',programming:'code','graphic-design':'pen-tool','career-support':'briefcase',education:'book-open',writing:'edit-3',entrepreneurship:'trending-up'};
const assetLogo = require('./assets/icon.png');
const assetHero = require('./assets/community-desk.jpg');

function Icon({name, size=20, color=green}) { return <Feather name={name} size={size} color={color}/>; }
function Label({children,style, ...props}) { return <Text {...props} style={[s.body,style]}>{children}</Text>; }
function Button({label, onPress, icon, primary=false, disabled=false}) {
  return <Pressable accessibilityRole="button" disabled={disabled} onPress={onPress} style={({pressed})=>[s.button,primary && s.primary,pressed && s.pressed,disabled && {opacity:.55}]}>
    {icon && <Icon name={icon} size={17} color={primary ? '#fff':green}/>}<Label style={[s.bold,primary && {color:'#fff'}]}>{label}</Label>
  </Pressable>;
}
function Row({title, description, icon, onPress}) {
  return <Pressable accessibilityRole="button" onPress={onPress} style={({pressed})=>[s.row,pressed && s.pressed]}>
    <View style={s.iconBox}><Icon name={icon}/></View><View style={s.flex}><Label style={s.bold}>{title}</Label>{!!description && <Label style={s.small}>{description}</Label>}</View><Icon name="chevron-right" size={18}/>
  </Pressable>;
}
async function openSite(path, member=false) {
  const target = SITE + '/' + path;
  const address = member ? SITE + '/login/?redirect_to=' + encodeURIComponent(target) : target;
  try { await Browser.openBrowserAsync(address); }
  catch { Alert.alert('Unable to open Beerandomly', 'Please try again.'); }
}

function useData(path, params={}) {
  const serial = JSON.stringify(params);
  const [revision, setRevision] = useState(0);
  const key = path + serial + ':' + revision;
  const [result,setResult] = useState({});
  useEffect(()=>{
    if (!path) return;
    const controller = new AbortController();
    getPublic(path, JSON.parse(serial), controller.signal)
      .then(data=>{if (!controller.signal.aborted) setResult({key,data});})
      .catch(e=>{if (!controller.signal.aborted) setResult({key,error:e.message});});
    return ()=>controller.abort();
  },[path,serial,key]);
  return {...(result.key===key ? result : {}), retry:()=>setRevision(r=>r+1)};
}
function Feedback({state}) {
  if (state.error) return <View style={s.empty}><Label style={s.bold}>Couldn’t load this section</Label><Label style={s.small}>{state.error}</Label><Button label="Try again" onPress={state.retry}/></View>;
  return <View style={s.loading}><ActivityIndicator color={green} accessibilityLabel="Loading"/></View>;
}
function Empty({title, children}) {
  return <View style={s.empty}><Icon name="message-circle"/><Label style={s.bold}>{title}</Label><Label style={s.small}>{children}</Label></View>;
}
function Avatar({person}) {
  const [failed,setFailed]=useState(false);
  if (person?.avatar && !failed) return <Image source={{uri:person.avatar}} style={s.avatar} onError={()=>setFailed(true)}/>;
  return <View style={[s.avatar,s.center]}><Label style={s.bold}>{Array.from(person?.name || 'B')[0]}</Label></View>;
}
function Card({item, onPress}) {
  return <Pressable accessibilityRole="button" onPress={onPress} style={({pressed})=>[s.card,pressed && s.pressed]}>
    <View style={s.inline}><Avatar person={item.author}/><Label style={s.small}>{item.author?.name || 'Member'}</Label></View>
    <Label style={s.cardTitle}>{item.title}</Label><Label numberOfLines={3}>{item.excerpt}</Label>
    <Label style={s.meta}>{[item.category?.name, (item.comments_count || 0) + ' comments'].filter(Boolean).join('   ·   ')}</Label>
  </Pressable>;
}
function Listing({people=false, query='', category, openDetail, version=0}) {
  const params = people ? {type:'people',q:query} : {tab:'latest',q:query,category_id:category?.id};
  const endpoint = people || query ? 'search' : 'feed';
  const base = useData(endpoint,{...params,page:1});
  const [extra,setExtra]=useState({items:[],page:1});
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState('');
  const pending=useRef(null);
  useEffect(()=>()=>pending.current?.abort(),[]);
  async function more() {
    if (pending.current) return;
    const c = new AbortController();
    pending.current=c; setBusy(true); setError('');
    try {
      const next=extra.page+1;
      const data=await getPublic(endpoint,{...params,page:next},c.signal);
      if(!c.signal.aborted) setExtra(old=>({items:[...old.items,...data.items],page:next,more:data.more}));
    } catch(e) { if(!c.signal.aborted) setError(e.message); }
    finally { if(!c.signal.aborted) { pending.current=null; setBusy(false); } }
  }
  if (!base.data) return <Feedback state={base}/>;
  const unique = new Map([...base.data.items,...extra.items].map(item=>[item.id,item]));
  if (!unique.size) return <Empty title={people ? 'No members found' : query || category ? 'No matching posts' : 'The hive is quiet'}>{people || query || category ? 'Try a different search or browse another topic.' : 'Start a conversation with the first public post.'}</Empty>;
  return <View style={s.stack}>{[...unique.values()].map(item=>people
    ? <Row key={item.id} title={item.name} description={item.headline || '@'+item.handle} icon="user" onPress={()=>openDetail({kind:'person',id:item.handle})}/>
    : <Card key={item.id} item={item} onPress={()=>openDetail({kind:'post',id:item.id})}/>)}
    {!!error && <Label style={s.small}>{error}</Label>}
    {(extra.more ?? base.data.more) && <Button label={busy?'Loading…':'Load more'} disabled={busy} onPress={more}/>}</View>;
}
function Detail({item}) {
  const person=item.kind==='person';
  const state=useData((person?'users/':'requests/')+encodeURIComponent(item.id));
  if (!state.data) return <Feedback state={state}/>;
  const d=state.data, path=(person?'u/':'r/')+encodeURIComponent(item.id)+'/';
  const share=()=>Share.share({message:SITE+'/'+path}).catch(()=>Alert.alert('Unable to share this link'));
  return <View style={s.stack}>
    {person ? <>
      <Avatar person={d.user}/><Label style={s.heading}>{d.user.name}</Label><Label style={s.small}>@{d.user.handle}</Label>
      {!!d.user.headline && <Label style={s.cardTitle}>{d.user.headline}</Label>}
      {d.restricted ? <Label>{d.message || 'Sign in to view this profile.'}</Label> : <>
        {!!d.bio && <Label>{d.bio}</Label>}{!!d.skills?.length && <><Label style={s.sub}>Skills</Label><Label>{d.skills.map(x=>x.name).join(' · ')}</Label></>}
        {d.stats && <Label style={s.meta}>{d.stats.helped} helped   ·   {d.stats.followers} followers</Label>}</>}
      <Button label={d.restricted?'Sign in to view profile':'Open full profile'} primary onPress={()=>openSite(path,d.restricted)}/>
    </> : <>
      {!!d.category?.name && <Label style={s.meta}>{d.category.name}</Label>}<Label style={s.heading}>{d.title}</Label>
      <View style={s.inline}><Avatar person={d.author}/><Label style={s.bold}>{d.author?.name || 'Member'}</Label></View>
      <Label selectable>{d.body}</Label><Label style={s.meta}>{d.comments_count || 0} comments   ·   {d.offers_count || 0} offers</Label>
      {!!d.attachments?.length && <Button label={'View attachments ('+d.attachments.length+')'} icon="paperclip" onPress={()=>openSite(path)}/>}
      <Button label="Join the conversation" primary onPress={()=>openSite(path,true)}/>
    </>}
    <Button label="Share link" icon="share-2" onPress={share}/>
  </View>;
}

function Community() {
  const [tab,setTab]=useState('Hive');
  const [item,setItem]=useState(null);
  const [topic,setTopic]=useState(null);
  const [draft,setDraft]=useState(''), [query,setQuery]=useState('');
  const [revision,setRevision]=useState(0);
  const [refreshing,setRefreshing]=useState(false);
  const tax=useData('taxonomy');
  const scroll=useRef(null);
  useEffect(()=>{scroll.current?.scrollTo({y:0,animated:false});},[tab,item,topic]);
  useEffect(()=>{
    const sub=BackHandler.addEventListener('hardwareBackPress',()=>{
      if(item){setItem(null);return true;}
      if(topic){setTopic(null);return true;}
      if(tab!=='Hive'){switchTab('Hive');return true;}
      return false;
    }); return ()=>sub.remove();
  },[item,topic,tab]);
  function switchTab(t) {setItem(null);setTopic(null);setDraft('');setQuery('');setTab(t);scroll.current?.scrollTo({y:0,animated:false});}
  function browse(t) {switchTab('Explore');setTopic(t);}
  function search(value) {setDraft(value);if(!value.trim()) setQuery('');}
  function refresh() {setRefreshing(true);setRevision(r=>r+1);tax.retry();}
  useEffect(()=>{if(refreshing && (tax.data || tax.error)) setRefreshing(false);},[refreshing,tax.data,tax.error]);
  const topics=tax.data?.categories || [];
  const searchBar=<View style={s.search}><Icon name="search"/><TextInput style={s.input} accessibilityLabel="Search" placeholder={tab==='People'?'Search names or skills':'Search public posts'} placeholderTextColor={muted} value={draft} onChangeText={search} returnKeyType="search" onSubmitEditing={()=>setQuery(draft.trim())} maxLength={100}/><Pressable accessibilityRole="button" accessibilityLabel="Run search" hitSlop={6} onPress={()=>setQuery(draft.trim())}><Label style={s.searchGo}>Search</Label></Pressable></View>;
  const listing=<Listing key={JSON.stringify([tab,topic?.id,query,revision])} people={tab==='People'} query={query} category={topic} openDetail={setItem}/>;
  return <SafeAreaView style={s.safe}><StatusBar barStyle="dark-content"/>
    <View style={s.brand}><Image source={assetLogo} style={{width:35,height:35,borderRadius:11}}/><Label style={s.wordmark}>beerandomly</Label><View style={s.flex}/><Pressable accessibilityLabel="Help and frequently asked questions" accessibilityRole="button" style={s.help} onPress={()=>openSite('faq/')}><Icon name="help-circle"/></Pressable></View>
    <ScrollView ref={scroll} keyboardShouldPersistTaps="handled" contentContainerStyle={s.scroll} refreshControl={!item && tab!=='Account'?<RefreshControl refreshing={refreshing} onRefresh={refresh} tintColor={green}/>:undefined}>
    <View style={s.content}>
      {item ? <><Button label={'Back to '+tab} icon="chevron-left" onPress={()=>setItem(null)}/><Detail item={item}/></>
      : tab==='Hive' ? <>
        <View style={s.hero}><Image source={assetHero} style={s.heroImage} resizeMode="cover" accessibilityLabel="An illustrated laptop, coffee cup and bee"/><View style={s.heroBody}><Text accessibilityRole="header" style={s.heroTitle}>The community hive</Text><Text style={s.heroText}>Ask for help or lend a hand to another online worker.</Text><Pressable accessibilityRole="button" style={s.heroButton} onPress={()=>openSite('ask/',true)}><Icon name="plus" size={17}/><Label style={s.bold}>Create a post</Label></Pressable></View></View>
        <View style={s.between}><Label style={s.sub}>Browse topics</Label><Pressable accessibilityRole="button" hitSlop={8} onPress={()=>switchTab('Explore')}><Label style={s.searchGo}>See all</Label></Pressable></View>
        {tax.data ? <View style={s.chips}>{topics.slice(0,4).map(t=><Pressable accessibilityRole="button" key={t.id} style={s.chip} onPress={()=>browse(t)}><Icon name={topicsIcons[t.slug]||'hash'} size={16}/><Label style={s.chipText}>{t.name}</Label></Pressable>)}</View> : <Feedback state={tax}/>}
        <Label style={s.sub}>Latest posts</Label>{listing}
      </> : tab==='Explore' ? <>
        <Label style={s.heading}>Explore</Label>{searchBar}
        {topic && <Button label={'Clear topic · '+topic.name} icon="x" onPress={()=>setTopic(null)}/>}
        {!topic && !query && <><Label style={s.sub}>Topics</Label>{tax.data ? <View style={s.rows}>{topics.map(t=><Row key={t.id} title={t.name} icon={topicsIcons[t.slug]||'hash'} onPress={()=>setTopic(t)}/>)}</View> : <Feedback state={tax}/>}</>}
        <Label style={s.sub}>{query?'Search results':topic?topic.name:'All public posts'}</Label>{listing}
      </> : tab==='People' ? <>
        <Label style={s.heading}>Find people</Label>{searchBar}{listing}
      </> : <>
        <Label style={s.heading}>Your account</Label><Label>Continue on Beerandomly to use your existing Google sign-in and member tools.</Label>
        <Button label="Open my profile" primary icon="user" onPress={()=>openSite('me/',true)}/>
        <View style={s.rows}>{[['Create a post','ask/','edit-3'],['Messages','messages/','message-square'],['My requests','requests/','list'],['My offers','offers/','briefcase'],['Saved posts','saved/','bookmark'],['Notifications','notifications/','bell'],['Credit wallet','wallet/','credit-card'],['Profile settings','settings/','settings']].map(([label,path,icon])=><Row key={path} title={label} icon={icon} onPress={()=>openSite(path,true)}/>)}</View>
      </>}
    </View></ScrollView>
    <View style={s.tabs}>{tabs.map(([name,icon])=><Pressable key={name} accessibilityRole="tab" accessibilityState={{selected:name===tab}} onPress={()=>switchTab(name)} style={s.tab}><View style={[s.tabIcon,name===tab && s.activeTab]}><Icon name={icon} size={20} color={name===tab?green:muted}/></View><Label style={[s.tabText,name===tab && {color:green,fontWeight:'800'}]}>{name}</Label></Pressable>)}</View>
  </SafeAreaView>;
}
export default function App() {return <SafeAreaProvider><Community/></SafeAreaProvider>;}
const s=StyleSheet.create({
  safe:{flex:1,backgroundColor:'#fff'},flex:{flex:1},center:{alignItems:'center',justifyContent:'center'},scroll:{flexGrow:1,backgroundColor:'#FAFBF7'},
  content:{width:'100%',maxWidth:720,alignSelf:'center',paddingHorizontal:18,paddingTop:18,paddingBottom:36,gap:15},
  body:{fontSize:16,lineHeight:23,color:ink},bold:{fontWeight:'700'},wordmark:{fontSize:23,lineHeight:30,fontWeight:'800',letterSpacing:-1.2},brand:{flexDirection:'row',alignItems:'center',gap:9,paddingHorizontal:18,minHeight:57,borderBottomWidth:1,borderColor:'#DDE5DB'},
  help:{width:44,height:44,alignItems:'center',justifyContent:'center'},hero:{overflow:'hidden',borderRadius:18,backgroundColor:green},heroImage:{width:'100%',height:160},heroBody:{padding:19,gap:8},heroTitle:{color:'#FFF8DA',fontSize:31,lineHeight:37,fontWeight:'800',letterSpacing:-1},heroText:{color:'#E1EFE4',fontSize:16,lineHeight:23},heroButton:{flexDirection:'row',alignSelf:'flex-start',alignItems:'center',gap:7,marginTop:5,paddingHorizontal:15,minHeight:44,borderRadius:10,backgroundColor:honey},
  heading:{fontSize:30,lineHeight:37,fontWeight:'800',letterSpacing:-1},sub:{fontSize:21,lineHeight:27,fontWeight:'700',letterSpacing:-.6},cardTitle:{fontSize:20,lineHeight:26,fontWeight:'700'},small:{color:muted,fontSize:15,lineHeight:21},meta:{fontSize:14,lineHeight:20,color:muted,fontWeight:'600'},
  button:{minHeight:44,alignItems:'center',justifyContent:'center',alignSelf:'flex-start',flexDirection:'row',gap:7,paddingHorizontal:15,borderWidth:1,borderColor:'#B8C9BC',borderRadius:10,backgroundColor:'#fff'},primary:{backgroundColor:green,borderColor:green},pressed:{opacity:.74},
  between:{flexDirection:'row',alignItems:'center',justifyContent:'space-between'},chips:{flexDirection:'row',flexWrap:'wrap',gap:8},chip:{backgroundColor:'#EAF0E7',borderRadius:24,paddingHorizontal:13,minHeight:42,flexDirection:'row',alignItems:'center',gap:7},chipText:{fontWeight:'600',fontSize:14},stack:{gap:12},inline:{flexDirection:'row',alignItems:'center',gap:9},avatar:{width:34,height:34,borderRadius:17,backgroundColor:'#F9DF96'},
  card:{padding:17,backgroundColor:'#fff',borderColor:'#D7E1D6',borderWidth:1,borderRadius:13,gap:9},empty:{alignItems:'flex-start',gap:6,padding:17,borderColor:'#D7E1D6',borderWidth:1,borderRadius:13,backgroundColor:'#fff'},loading:{padding:20},
  rows:{gap:1,backgroundColor:'#DBE3DA',borderWidth:1,borderColor:'#DBE3DA',borderRadius:14,overflow:'hidden'},row:{padding:13,gap:12,flexDirection:'row',alignItems:'center',backgroundColor:'#fff'},iconBox:{width:36,height:36,alignItems:'center',justifyContent:'center',backgroundColor:'#EDF3EA',borderRadius:10},
  search:{paddingHorizontal:12,flexDirection:'row',alignItems:'center',gap:9,backgroundColor:'#fff',borderColor:'#B7C6B9',borderWidth:1,borderRadius:11},input:{flex:1,paddingVertical:12,minHeight:48,fontSize:16,color:ink},searchGo:{color:green,fontSize:15,fontWeight:'700'},
  tabs:{flexDirection:'row',borderTopWidth:1,borderColor:'#DDE5DB',paddingVertical:5},tab:{alignItems:'center',flex:1,gap:2,minHeight:48},tabIcon:{width:48,height:27,alignItems:'center',justifyContent:'center',borderRadius:15},activeTab:{backgroundColor:'#FBE9AA'},tabText:{color:muted,fontSize:13,lineHeight:18},
});
